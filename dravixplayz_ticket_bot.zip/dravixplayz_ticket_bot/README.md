# Dravixplayz Bot | pravite:1

A custom Discord ticket bot built with Python and `discord.py`.

## Features
- Ticket panel with Player Report, Ban Appeal, Partnership, General Support, and Staff Application.
- Private ticket channels visible to the ticket creator and configured staff roles.
- Ticket form modal for issue details and evidence.
- Staff application form with Helper, Moderator, Admin, Developer, and Support Team positions.
- Staff-only application Accept / Reject buttons, with a DM notification attempt.
- Staff Claim button.
- Close ticket button and transcript `.txt` output to a configured log channel.
- Staff-only delete button after closing.
- Slash commands: `/ticketpanel` and `/ticketsetup`.

## 1. Create the Discord application
1. Open https://discord.com/developers/applications and create an application.
2. Open **Bot** and add a bot user.
3. Copy the bot token and keep it private. Never post it in chat or upload it publicly.
4. Under **Bot > Privileged Gateway Intents**, enable **Server Members Intent** and **Message Content Intent**.
5. Under **OAuth2 > URL Generator**, select scopes `bot` and `applications.commands`.
6. Give the bot permissions: View Channels, Send Messages, Read Message History, Manage Channels, Attach Files, Embed Links, and Use Application Commands. Open the generated URL and add it to your server.

## 2. Configure the project
1. Install Python 3.10 or newer.
2. Extract this ZIP.
3. Copy `.env.example` to a new file named `.env`.
4. Fill in `DISCORD_TOKEN`.
5. Add your server ID to `GUILD_ID` while testing (slash commands sync faster to one server).
6. Add staff role IDs to `STAFF_ROLE_IDS` separated by commas.
7. Add the IDs for your application review channel and transcript log channel.
8. Optionally set `TICKET_CATEGORY_ID` to the category where ticket channels should be created.

To copy IDs in Discord: User Settings > Advanced > Developer Mode, then right-click/tap-and-hold the relevant server, role, category, or channel and choose Copy ID. On mobile, the menu wording can vary.

## 3. Run it
In the project folder:

```bash
python -m venv .venv
```

Activate the environment:
- Windows: `.venv\Scripts\activate`
- macOS/Linux: `source .venv/bin/activate`

Then run:

```bash
pip install -r requirements.txt
python bot.py
```

When the console says the bot is online, run `/ticketpanel` in the channel where you want the ticket panel posted. Use `/ticketsetup` to check required settings.

## 4. 24/7 hosting
For continuous operation, deploy the project to a reputable Python hosting service that supports always-on workers. Upload `bot.py` and `requirements.txt`, install dependencies with `pip install -r requirements.txt`, and configure the environment variables in the host's secret/environment-variable settings. Do not upload your `.env` file to a public repository. Some free hosts sleep or stop workers, so 24/7 operation may require a paid always-on plan.

## Important notes
- The `Staff Application` modal accepts one of these exact position names: `Helper`, `Moderator`, `Admin`, `Developer`, `Support Team`.
- Set `APPLICATION_REVIEW_CHANNEL_ID` to a staff-only channel; anyone who can see that channel can see applicant information.
- Set `TRANSCRIPT_LOG_CHANNEL_ID` to a staff-only channel because transcripts can contain private conversations.
- Give the bot role a position high enough to manage the ticket channels it creates.
- A DM can fail if the applicant blocks DMs. The decision still appears in the review channel and ticket.
- This is a starter project. Test it in a private test server before using it in a large community.
